# tilly-goodbye

Example plugin for tilly.
